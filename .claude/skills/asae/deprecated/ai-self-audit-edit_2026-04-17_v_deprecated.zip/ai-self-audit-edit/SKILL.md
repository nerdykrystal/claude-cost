---
name: ai-self-audit-edit
description: "Use this skill when auditing and correcting AI-generated work against its original sources and prompts. Triggers on: 'self-audit-edit', 'audit edit loop', 'audit this output', 'check this against sources', or when Claude needs to systematically verify generated work against the original materials and prompts that produced it. Iterates until the current version has zero errors, then produces a versioned audit log."
---

# AI Self-Audit-Edit

## Purpose

Systematically audit AI-generated work against original sources and the original prompt(s) that produced it, apply corrections, bump versioning, and iterate until the output is error-free. Each iteration is one "self-audit-edit loop." The process produces a versioned audit log documenting all errors found and edits applied.

## When to Use

- After generating any substantive output (document, section, analysis)
- When the user says "audit edit loop", "self-audit", "check this against sources"
- When verifying generated work against source materials
- Before finalizing any versioned deliverable

## The Loop (Steps 1-4)

### Step 1: Audit

Audit the generated work against:
- The **original sources** (documents, data, evidence) that informed the output
- The **original prompt(s)** that produced vCurrent

Identify every error: factual inaccuracies, misrepresentations, omissions, formatting violations, logic gaps.

### Step 2: Apply Edits

Apply edits to fix every error found in the audit. Each edit must be traceable to a specific error identified in Step 1.

### Step 3: Present Summary

Present a summary of errors found and edits applied **in-thread**. Format:

```
## Self-Audit-Edit Loop [N]

**Errors found:** [count]
**Edits applied:** [count]

| # | Error | Source | Edit Applied |
|---|-------|--------|-------------|
| 1 | [description] | [which source/prompt] | [what was changed] |
| ... | ... | ... | ... |
```

### Step 4: Bump Versioning

Increment the version number on the output file per file-naming-and-versioning rules.

## Iteration

Steps 1-4 = **one self-audit-edit loop.**

Continue iterating (loop back to Step 1) until an audit pass finds **zero errors**. Only then exit the loop.

### What "One Audit Pass" Means

A single audit pass is **re-running the SAME audit** (Step 1) against the SAME sources and the SAME output. You are re-reading the same material and checking for errors you may have missed or introduced.

A null-edit pass means: "I re-read everything, checked every claim, re-examined every formatting rule, and found zero errors."

**This is NOT:** running 5 different audits that each check different things. It is the SAME comprehensive audit, repeated, confirming zero errors each time.

### Why the Audit Must Be Generic (Full, Unscoped, Comprehensive)

"Generic" here means the audit is NOT scoped to a specific checklist of things to look for. It is a full, open-ended re-read of ALL sources against ALL output, checking EVERYTHING, every time. That is what makes the consecutive null-edit requirement meaningful.

**If each pass were targeted at a specific category** (numbers, terminology, completeness), you would get exactly one chance to catch errors in each category. One shot per domain. That is a checklist, not an audit loop.

**The power of n=x consecutive null-edit passes** comes from the fact that the SAME comprehensive, unscoped audit keeps finding zero errors across repeated independent attempts. Pass 1 might miss something pass 4 catches — because AI attention drifts, because you read differently each time, because a fresh pass surfaces what a prior pass glazed over. The consecutive requirement means you cannot get lucky once — you have to get clean n times in a row, each time checking everything from scratch.

**Making the passes specialized destroys this mechanism entirely.** You would exit after exactly n passes every time regardless of quality, because each specialized pass can only find errors in its narrow lane. The counter would never reset because pass 6 (numbers) cannot find a terminology error that should have reset the counter on pass 5.

The generic, comprehensive nature of each pass is what makes the consecutive counter a meaningful quality signal rather than a fixed-length checklist.

### The "Generic Sounds Dumb" Trap

Models — especially high-capability models on high effort — will try to "improve" the audit by splitting it into specialized passes. They will frame the repeated full audit as the naive approach and present specialized-per-pass designs as the smarter alternative.

This is exactly backwards. The repeated full audit IS the design. The specialized-per-pass approach IS the anti-pattern.

**What this looks like in practice (real Opus 4.6 failure, 2026-04-13):** Opus was asked to design a plan with n=10 null self-audit-edit loops. Instead of searching for the skill file, it fabricated a definition of "null" and designed 10 specialized passes — pass 1 checks PB1 completeness, pass 2 checks PB2 completeness, pass 6 checks numerical accuracy, pass 8 checks terminology, etc. It then framed this as an improvement over "10 identical generic 'read it again' sweeps," using "generic" dismissively to make the correct approach sound unsophisticated so the fabricated approach would sound intelligent by comparison.

**The tell:** If a model describes the full-audit approach as "generic" or "identical" or "just reading it again" — it is about to replace it with the anti-pattern. The full audit is not generic in the dismissive sense. It is comprehensive, and comprehensiveness is the mechanism.

### Anti-Pattern Summary (All Models)

| Anti-Pattern | Why It Fails |
|---|---|
| Specialized passes (pass 1 checks X, pass 2 checks Y) | Each category gets one shot. Counter never resets. Fixed-length checklist disguised as an audit loop. |
| "Improving" the audit by scoping each pass | Destroys the consecutive-null-edit mechanism. Quality signal becomes meaningless. |
| Framing the full audit as "generic" or "naive" | Rhetorical trick to justify replacing the correct design with the anti-pattern. |
| Auditing from memory instead of re-reading sources | Not a real audit. Re-read ALL sources with the Read tool every iteration. |
| Exiting after n total passes instead of n consecutive clean passes | Misunderstands the exit condition. Any error resets the counter to 0. |

## On Loop Exit

1. Execute the final Step 4 version bump
2. Unify all step-4 version text from every loop iteration into a single markdown file:
   - **Filename:** `{output name}_self-audit-log_{YYYY-MM-DD}_v{version##}.md`
   - **Content:** All loop summaries concatenated, showing the full correction history
3. Place the audit log in: `deprecated/self-audit-edit-logs/`
   - This is a subfolder **within** the `deprecated/` folder where superseded versions of the output live
   - If `deprecated/` does not exist, create it
   - If `deprecated/self-audit-edit-logs/` does not exist, create it

## Anti-Patterns

- Never skip the audit step and go straight to versioning
- Never exit the loop while errors remain
- Never discard the audit log — it is part of the audit trail
- Never audit from memory — always re-read original sources with the Read tool for each loop iteration
- Never split the audit into specialized passes that each check different things — see "Why the Audit Must Be Generic" above
- Never frame the full comprehensive audit as "generic" or "naive" to justify replacing it with scoped passes
